import os

class Config:

    BOT_TOKEN = ""

    SESSION_NAME = ""

    API_ID = ""

    API_HASH = ""

    CLIENT_ID = ""

    CLIENT_SECRET = ""

    AUTH_USERS = [942731625]

    VIDEO_DESCRIPTION = ""

    VIDEO_CATEGORY = ""

    VIDEO_TITLE_PREFIX = ""

    VIDEO_TITLE_SUFFIX = ""
    
    DEBUG = bool()

    UPLOAD_MODE = "unlisted"
    
    CRED_FILE = "auth_token.txt"